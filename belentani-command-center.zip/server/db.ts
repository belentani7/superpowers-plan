import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertProject, InsertUser, Project, projects, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export function calculateProjectScore(project: Pick<Project, "commits30d" | "hasDeploy" | "hasUsers" | "hasDocs" | "hasRevenue" | "lastActivityAt">) {
  const commitSignal = Math.min(30, Math.round((project.commits30d ?? 0) / 2));
  const freshness = project.lastActivityAt
    ? Math.max(0, 10 - Math.floor((Date.now() - new Date(project.lastActivityAt).getTime()) / 86_400_000))
    : 0;
  return Math.min(100, commitSignal + (project.hasDeploy ? 20 : 0) + (project.hasUsers ? 20 : 0) + (project.hasDocs ? 10 : 0) + (project.hasRevenue ? 10 : 0) + freshness);
}

export async function listProjects(): Promise<Project[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(projects).orderBy(desc(projects.score), desc(projects.updatedAt));
}

export async function insertProjects(items: InsertProject[]) {
  const db = await getDb();
  if (!db || items.length === 0) return [];
  const normalized = items.map(item => ({
    ...item,
    score: calculateProjectScore(item as Project),
  }));
  await db.insert(projects).values(normalized);
  return listProjects();
}

export async function deleteAllProjects() {
  const db = await getDb();
  if (!db) return;
  await db.delete(projects);
}

export async function replaceProjects(items: InsertProject[]) {
  const db = await getDb();
  if (!db) return [];
  await db.delete(projects);
  if (items.length === 0) return [];
  await db.insert(projects).values(items.map(item => ({ ...item, score: calculateProjectScore(item as Project) })));
  return listProjects();
}
